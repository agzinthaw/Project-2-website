package action;

import com.opensymphony.xwork2.ActionSupport;

import dao.StrutsDao;

public class Register extends ActionSupport {

	private static final long serialVersionUID = 1L;
	
	private String uname, uemail, fname, lname, pass, rpass, phone, address;
	private String msg = "";
	StrutsDao sdo = null;
	int ctr = 0;

	@Override
	public String execute() throws Exception {
		sdo = new StrutsDao();

		try {
			ctr = sdo.registerUser(uname, uemail, fname, lname, pass, rpass, phone, address);
			if (ctr > 0) {
				return "success";
			} else {
				msg = "Error";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "REGISTER";
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public int getCtr() {
		return ctr;
	}

	public void setCtr(int ctr) {
		this.ctr = ctr;
	}
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getRpass() {
		return rpass;
	}
	public void setRpass(String rpass) {
		this.rpass = rpass;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
